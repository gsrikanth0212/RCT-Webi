# WebI Migration Audit — Sales Dashboard

**Overall quality score: 100.0 / 100**

## Summary

| Metric | Value |
|---|---|
| Document | Sales Dashboard |
| Reports | 1 |
| Sections | 1 |
| Blocks | 2 |
| Data Providers | 1 |
| Universe Objects | 19 |
| Variables | 0 |
| Merged Dimensions | 0 |
| Input Controls | 0 |
| Tables Generated | 1 |
| Relationships Generated | 0 |

## Quality Score Breakdown

| Dimension | Score | Basis | Detail |
|---|---|---|---|
| Data Model Match | 100.0 | MEASURED | 1 table(s), 0 relationship(s), 0 artifact validation error(s). |
| Semantic Match | 100.0 | HEURISTIC | 0 ambiguous field name reference(s) out of 19 universe object(s). |
| Calculation Match | 100.0 | MEASURED | 0/0 variable(s) converted to DAX with SUCCESS status. |
| Filter Match | 100.0 | MEASURED | 0/0 query filter(s) applied as Power BI report filters. |
| Prompt Match | 100.0 | HEURISTIC | 0/0 prompt(s)/input control(s) mapped to Slicer visuals (approximated — see notes). |
| Visual Match | 100.0 | MEASURED | 2 block(s) classified into Power BI visuals; 2 exact, 0 approximated, 0 unsupported. |
| Field Mapping Match | 100.0 | MEASURED | 0 unresolved field reference(s) out of 4 placed into visual field wells. |
| Layout Match | 100.0 | HEURISTIC | 0/1 section break(s) rendered as a static label instead of a repeating per-value section (see WEBI_UNSUPPORTED_FEATURES.md). |

## Calculations (Variables → DAX)

| Variable | Status | Confidence | DAX |
|---|---|---|---|

## Artifact Validation

0 error(s), 0 warning(s).


## Semantic Validation


## Visuals, Filters & Prompts

