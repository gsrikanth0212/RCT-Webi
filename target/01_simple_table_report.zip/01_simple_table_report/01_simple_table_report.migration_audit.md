# WebI Migration Audit — Regional Sales Summary

**Overall quality score: 95.0 / 100**

## Summary

| Metric | Value |
|---|---|
| Document | Regional Sales Summary |
| Reports | 1 |
| Sections | 1 |
| Blocks | 1 |
| Data Providers | 1 |
| Universe Objects | 5 |
| Variables | 1 |
| Merged Dimensions | 0 |
| Input Controls | 0 |
| Tables Generated | 2 |
| Relationships Generated | 0 |

## Quality Score Breakdown

| Dimension | Score | Basis | Detail |
|---|---|---|---|
| Data Model Match | 100.0 | MEASURED | 2 table(s), 0 relationship(s), 0 artifact validation error(s). |
| Semantic Match | 100.0 | HEURISTIC | 0 ambiguous field name reference(s) out of 5 universe object(s). |
| Calculation Match | 100.0 | MEASURED | 1/1 variable(s) converted to DAX with SUCCESS status. |
| Filter Match | 50.0 | MEASURED | 1/2 query filter(s) applied as Power BI report filters. |
| Prompt Match | 100.0 | HEURISTIC | 0/0 prompt(s)/input control(s) mapped to Slicer visuals (approximated — see notes). |
| Visual Match | 100.0 | MEASURED | 1 block(s) classified into Power BI visuals; 1 exact, 0 approximated, 0 unsupported. |
| Field Mapping Match | 100.0 | MEASURED | 0 unresolved field reference(s) out of 6 placed into visual field wells. |
| Layout Match | 100.0 | HEURISTIC | 0/1 section break(s) rendered as a static label instead of a repeating per-value section (see WEBI_UNSUPPORTED_FEATURES.md). |

## Calculations (Variables → DAX)

| Variable | Status | Confidence | DAX |
|---|---|---|---|
| Avg Unit Price | SUCCESS | 1.0 | `([Total Sales Revenue] / [Total Quantity Sold])` |

## Artifact Validation

0 error(s), 0 warning(s).


## Semantic Validation


## Visuals, Filters & Prompts

- **QueryFilter** `QueryFilter` → `` [UNSUPPORTED, confidence 0.00]
  - Query filter on 'Fiscal Year' (Data Provider 'Sales Query') could not be resolved to a field — not applied.
